import Index from "./components/user"
import "./components/index.css"
export default function App(){
  return (
    <Index />
  )
}