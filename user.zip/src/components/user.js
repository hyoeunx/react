export default function index(){
    return(
        <>
        <nav className="NavBar">
        <div className="title">
            타용
        </div>
        <div className="sm-title">
            부산광역시 <br />버스 정보 시스템
        </div>
        <div className="Menu">
            <p>실시간 버스 정보 검색</p>
            <p>경로 설정</p>
            <p>사용자 설정</p>
            <p>버스명단</p>
        </div>
        <img className="img" src="image/profile.png"></img>
        <div className="Login">
            로그인
        </div>
    </nav>
    <h2 className="ti">
        사용자 설정
    </h2>
    <div className="exp">집에서 버스정류장까지 걸리는 시간을 바꿔보세요</div>
    <div className="boxx"></div>
    <input type="radio" className="ic"></input>
    <div className="kk">경로 2</div>
    <img className="xx" src="image\gg_arrows-exchange-alt-v.png"></img>
    <div className="stt">출발지 (집)</div>
    <div className="arr">버스정류장</div>
    <div className="boxxx"></div>
    <div className="boxxs"></div>
    <div className="boh">보헤이브빌2차</div>
    <div className="had">하단역</div>
    <div className="tj">버스정류장까지 도보로 걸리는 시간이 어떻게 되시나요?</div>
    <div className="boxsx"></div>
    <img className="busx" src="image\icon _bus_.png"></img>
    <div className="bti">도보 소요 시간을 분 단위로 입력해주세요 :</div>
    <div className="mii">5분</div>
    <div className="sav">저장하시겠습니까?</div>
    <div className="bob"></div>
    <div className="bb"></div>
    <div className="yy">예</div>
    <div className="nn">아니요</div>
    </>
    )
}